<?php snippet('header') ?>

<main>
<main>
  <header class="intro">
    <h1><?= $page->title() ?></h1>
  </header>

  <div class="events">
    <?php foreach ($page->children()->listed()->sortBy('date', 'desc') as $event): ?>
    <article class="event">
      <header class="event-header">
        <a href="<?= $event->url() ?>">
          <h2><?= $event->title() ?></h2>
          <time><?= $event->date()->toDate('d F Y') ?></time>
        </a>
      </header>
    </article>
    <?php endforeach ?>
  </div>

</main>
</main>

<?php snippet('footer') ?>
