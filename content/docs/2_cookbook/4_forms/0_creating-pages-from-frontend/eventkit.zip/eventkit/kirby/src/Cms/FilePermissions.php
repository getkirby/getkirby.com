<?php

namespace Kirby\Cms;

class FilePermissions extends ModelPermissions
{
    protected $category = 'files';
}
