import Products from "./components/Products.vue";

panel.plugin("getkirby/products", {
	components: {
		"k-products-view": Products
	}
});
