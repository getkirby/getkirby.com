<?php

return [
    'label' => 'Products',
    'icon'  => 'cart',
    'query' => function (string $query) {
        $products = products();
        $results  = [];

        foreach ($products as $product) {
            if (Str::contains($product['title'], $query, true) === true) {
                $results[] = [
                    'text' => $product['title'],
                    'link' => '/products',
                    'image' => [
                        'icon' => 'cart',
                        'back' => 'purple-400'
                    ]
                ];
            }
        }

        return $results;
    }
];
