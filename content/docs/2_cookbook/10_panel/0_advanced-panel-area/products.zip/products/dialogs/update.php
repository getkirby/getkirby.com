<?php

return [
    'pattern' => 'products/(:any)/update',
    'load'    => function (string $id) {
        $product = products()[$id];

        return [
            'component' => 'k-form-dialog',
            'props' => [
                'fields' => [
                    'title' => [
                        'label' => 'Title',
                        'type'  => 'text'
                    ],
                    'type' => [
                        'label' => 'Type',
                        'type'  => 'text'
                    ],
                    'description' => [
                        'label' => 'Description',
                        'type'  => 'textarea',
                        'buttons' => false
                    ],
                    'price' => [
                        'label' => 'Price',
                        'type'  => 'number',
                        'step'  => 0.01,
                        'before' => '€'
                    ]
                ],
                'value' => $product
            ]
        ];
    },
    'submit' => function (string $id) {
        $products = products();
        $products[$id] = get();

        Data::write(__DIR__ . '/../products.json', $products);

        return true;
    }
];
