<template>
  <k-inside>
    <k-view>
      <k-header>Product</k-header>
      <table class="k-products">
        <tr>
          <th>Title</th>
          <th class="k-product-type">Type</th>
          <th>Description</th>
          <th class="k-product-price">Price</th>
          <th class="k-product-options"></th>
        </tr>
        <tr>
          <td>{{ product.title }}</td>
          <td class="k-product-type">{{ product.type }}</td>
          <td>{{ product.description }}</td>
          <td class="k-product-price">{{ price(product.price) }}</td>
          <td class="k-product-options">
            <k-options-dropdown :options="'products/' + id" />
          </td>
        </tr>
      </table>
    </k-view>
  </k-inside>
</template>

<script>
export default {
  props: {
    product: Array
  },
  methods: {
    price(price) {
      return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(price);
    },
  }
};
</script>
