<template>
  <k-inside>
    <k-view>
      <k-header>Products</k-header>
        <k-text align="right">
          <k-button
            text='Add'
            icon='add'
            @click="$dialog('products/add')"
          />
        </k-text>
      <table class="k-products">
        <tr>
          <th>Title</th>
          <th class="k-product-type">Type</th>
          <th>Description</th>
          <th class="k-product-price">Price</th>
          <th class="k-product-options"></th>
        </tr>
        <tr v-for="(product, id) in products" :key="id">
          <td><a :href="productlink(id)">{{ product.title }}</a></td>
          <td class="k-product-type">{{ product.type }}</td>
          <td>{{ product.description }}</td>
          <td class="k-product-price">{{ price(product.price) }}</td>
          <td class="k-product-options">
            <k-options-dropdown :options="'products/' + id" />
          </td>
        </tr>
      </table>
    </k-view>
  </k-inside>
</template>

<script>
export default {
  props: {
    products: Array
  },
  methods: {
    price(price) {
      return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(price);
    },
    productlink(id) {
      return 'products/' + id;
    }
  }
};
</script>

<style>
.k-products {
  width: 100%;
  table-layout: fixed;
  border-spacing: 1px;
}
.k-products td,
.k-products th {
  text-align: left;
  font-size: var(--text-sm);
  padding: var(--spacing-2);
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  background: var(--color-white);
}
.k-product-type {
  width: 8rem;
}
.k-product-price {
  width: 5rem;
  font-variant-numeric: tabular-nums;
  text-align: right !important;
}
.k-product-options {
  padding: 0 !important;
  width: 3rem;
  overflow: visible !important;
}
</style>
