<?php

use Kirby\Data\Data;

return [
    'pattern' => 'products/add',
    'load'    => function () {
        return [
            'component' => 'k-form-dialog',
            'props' => [
                'fields' => [
                    'title' => [
                        'label' => 'Title',
                        'type'  => 'text'
                    ],
                    'type' => [
                        'label' => 'Type',
                        'type'  => 'text'
                    ],
                    'description' => [
                        'label' => 'Description',
                        'type'  => 'textarea',
                        'buttons' => false
                    ],
                    'price' => [
                        'label' => 'Price',
                        'type'  => 'number',
                        'step'  => 0.01,
                        'before' => '€'
                    ]
                ],
                'value' => [
                    'title' => get('title'),
                    'type' => get('type'),
                    'description' => get('description'),
                    'price' => get('price'),
                ],
            ]
        ];
    },
    'submit' => function () {
        $products = products();
        $products[] = get();

        Data::write(__DIR__ . '/../products.json', $products);

        return true;
    }
];
