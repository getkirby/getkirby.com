<?php

use Kirby\Data\Data;

return [
    'pattern' => 'products/(:any)/delete',
    'load' => function (string $id) {
        return [
            'component' => 'k-remove-dialog',
            'props' => [
                'text' => 'Do you really want to delete this product?'
            ]
        ];
    },
    'submit' => function (string $id) {
        $products = products();

        unset($products[$id]);

        Data::write(__DIR__ . '/../products.json', $products);

        return true;
    }
];
