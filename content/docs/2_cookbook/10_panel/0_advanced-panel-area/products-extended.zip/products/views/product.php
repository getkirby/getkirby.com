<?php

return [
    'pattern' => 'products/(:any)',
    'action'  => function ($id) {
        return [
            'component' => 'k-product-view',
            'props' => [
                'product' => products()[$id]
            ],
        ];
    }
];
