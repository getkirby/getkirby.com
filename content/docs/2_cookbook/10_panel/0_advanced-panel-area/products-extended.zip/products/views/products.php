<?php

return [
    'pattern' => 'products',
    'action'  => function () {
        return [
            'component' => 'k-products-view',
            'props' => [
                'products' => products()
            ],
            'search' => 'products'
        ];
    }
];
