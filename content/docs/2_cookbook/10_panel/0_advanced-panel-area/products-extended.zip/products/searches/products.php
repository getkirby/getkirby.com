<?php

use Kirby\Toolkit\Str;

return [
    'label' => 'Products',
    'icon'  => 'cart',
    'query' => function (string $query) {
        $products = products();
        $results  = [];

        foreach ($products as $key => $product) {
            if (Str::contains($product['title'], $query, true) === true) {
                $results[] = [
                    'text' => $product['title'],
                    'link' => '/products/' . $key,
                    'image' => [
                        'icon' => 'cart',
                        'back' => 'purple-400'
                    ]
                ];
            }
        }

        return $results;
    }
];
