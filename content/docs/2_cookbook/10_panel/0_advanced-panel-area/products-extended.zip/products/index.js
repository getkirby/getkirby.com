(function() {
  "use strict";
  var render$1 = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("k-inside", [_c("k-view", [_c("k-header", [_vm._v("Products")]), _c("k-text", { attrs: { "align": "right" } }, [_c("k-button", { attrs: { "text": "Add", "icon": "add" }, on: { "click": function($event) {
      return _vm.$dialog("products/add");
    } } })], 1), _c("table", { staticClass: "k-products" }, [_c("tr", [_c("th", [_vm._v("Title")]), _c("th", { staticClass: "k-product-type" }, [_vm._v("Type")]), _c("th", [_vm._v("Description")]), _c("th", { staticClass: "k-product-price" }, [_vm._v("Price")]), _c("th", { staticClass: "k-product-options" })]), _vm._l(_vm.products, function(product, id) {
      return _c("tr", { key: id }, [_c("td", [_c("a", { attrs: { "href": _vm.productlink(id) } }, [_vm._v(_vm._s(product.title))])]), _c("td", { staticClass: "k-product-type" }, [_vm._v(_vm._s(product.type))]), _c("td", [_vm._v(_vm._s(product.description))]), _c("td", { staticClass: "k-product-price" }, [_vm._v(_vm._s(_vm.price(product.price)))]), _c("td", { staticClass: "k-product-options" }, [_c("k-options-dropdown", { attrs: { "options": "products/" + id } })], 1)]);
    })], 2)], 1)], 1);
  };
  var staticRenderFns$1 = [];
  var Products_vue_vue_type_style_index_0_lang = "\n.k-products {\n  width: 100%;\n  table-layout: fixed;\n  border-spacing: 1px;\n}\n.k-products td,\n.k-products th {\n  text-align: left;\n  font-size: var(--text-sm);\n  padding: var(--spacing-2);\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  background: var(--color-white);\n}\n.k-product-type {\n  width: 8rem;\n}\n.k-product-price {\n  width: 5rem;\n  font-variant-numeric: tabular-nums;\n  text-align: right !important;\n}\n.k-product-options {\n  padding: 0 !important;\n  width: 3rem;\n  overflow: visible !important;\n}\n";
  function normalizeComponent(scriptExports, render2, staticRenderFns2, functionalTemplate, injectStyles2, scopeId, moduleIdentifier, shadowMode) {
    var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
    if (render2) {
      options.render = render2;
      options.staticRenderFns = staticRenderFns2;
      options._compiled = true;
    }
    if (functionalTemplate) {
      options.functional = true;
    }
    if (scopeId) {
      options._scopeId = "data-v-" + scopeId;
    }
    var hook;
    if (moduleIdentifier) {
      hook = function(context) {
        context = context || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext;
        if (!context && typeof __VUE_SSR_CONTEXT__ !== "undefined") {
          context = __VUE_SSR_CONTEXT__;
        }
        if (injectStyles2) {
          injectStyles2.call(this, context);
        }
        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      };
      options._ssrRegister = hook;
    } else if (injectStyles2) {
      hook = shadowMode ? function() {
        injectStyles2.call(this, (options.functional ? this.parent : this).$root.$options.shadowRoot);
      } : injectStyles2;
    }
    if (hook) {
      if (options.functional) {
        options._injectStyles = hook;
        var originalRender = options.render;
        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }
    return {
      exports: scriptExports,
      options
    };
  }
  const script$1 = {
    props: {
      products: Array
    },
    methods: {
      price(price) {
        return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(price);
      },
      productlink(id) {
        return "products/" + id;
      }
    }
  };
  const __cssModules$1 = {};
  var __component__$1 = /* @__PURE__ */ normalizeComponent(script$1, render$1, staticRenderFns$1, false, injectStyles$1, null, null, null);
  function injectStyles$1(context) {
    for (let o in __cssModules$1) {
      this[o] = __cssModules$1[o];
    }
  }
  var Products = /* @__PURE__ */ function() {
    return __component__$1.exports;
  }();
  var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("k-inside", [_c("k-view", [_c("k-header", [_vm._v("Product")]), _c("table", { staticClass: "k-products" }, [_c("tr", [_c("th", [_vm._v("Title")]), _c("th", { staticClass: "k-product-type" }, [_vm._v("Type")]), _c("th", [_vm._v("Description")]), _c("th", { staticClass: "k-product-price" }, [_vm._v("Price")]), _c("th", { staticClass: "k-product-options" })]), _c("tr", [_c("td", [_vm._v(_vm._s(_vm.product.title))]), _c("td", { staticClass: "k-product-type" }, [_vm._v(_vm._s(_vm.product.type))]), _c("td", [_vm._v(_vm._s(_vm.product.description))]), _c("td", { staticClass: "k-product-price" }, [_vm._v(_vm._s(_vm.price(_vm.product.price)))]), _c("td", { staticClass: "k-product-options" }, [_c("k-options-dropdown", { attrs: { "options": "products/" + _vm.id } })], 1)])])], 1)], 1);
  };
  var staticRenderFns = [];
  const script = {
    props: {
      product: Array
    },
    methods: {
      price(price) {
        return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(price);
      }
    }
  };
  const __cssModules = {};
  var __component__ = /* @__PURE__ */ normalizeComponent(script, render, staticRenderFns, false, injectStyles, null, null, null);
  function injectStyles(context) {
    for (let o in __cssModules) {
      this[o] = __cssModules[o];
    }
  }
  var Product = /* @__PURE__ */ function() {
    return __component__.exports;
  }();
  panel.plugin("getkirby/products", {
    components: {
      "k-products-view": Products,
      "k-product-view": Product
    }
  });
})();
