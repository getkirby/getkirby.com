panel.plugin('your-project/faq-block', {
	blocks: {
		faq: {
			template: `
				<div @dblclick="open" class="faq">
					<h2>
						{{ content.headline }}
					</h2>

					<div v-html="content.text"></div>

					<dl v-for="item in content.blocks">
						<dt v-html="item.content.question"></dt>
						<dd v-html="item.content.answer"></dd>
					</dl>
				</div>
		      `
		},
		faq_item: {
			template: `
				<div @dblclick="open">
					<strong contenteditable="true" @blur="update({ question: $event.target.innerText });">{{content.question}}</strong>
					<div v-html="content.answer" contenteditable="true" @blur="update({ answer: $event.target.innerText });"></div>
				</div>
			`
		}
	}
});