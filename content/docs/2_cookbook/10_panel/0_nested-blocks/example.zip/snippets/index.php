<div class="my-faq-block">
  <h2><?= $block->content()->headline()->html() ?></h2>
  <p><?= $block->content()->text() ?></p>
  <dl>
    <?php
    foreach ($block->content()->blocks()->toBlocks() as $nested_block):
      snippet('blocks/' . $nested_block->type(),
        [
          'block' => $nested_block,
        ]
      );
    endforeach;
    ?>
  </dl>
</div>