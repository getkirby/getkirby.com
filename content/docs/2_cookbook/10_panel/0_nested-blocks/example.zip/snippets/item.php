<dt><?= $block->question() ?></dt>
<dd><?= $block->answer() ?></dd>