<?php
Kirby::plugin('your-project/faq-block', [

  'blueprints' => [
    'blocks/faq'      => __DIR__ . '/blueprints/index.yml',
    'blocks/faq_item' => __DIR__ . '/blueprints/item.yml'
  ],

  'snippets'   => [
    'blocks/faq'      => __DIR__ . '/snippets/index.php',
    'blocks/faq_item' => __DIR__ . '/snippets/item.php'
  ]
]);