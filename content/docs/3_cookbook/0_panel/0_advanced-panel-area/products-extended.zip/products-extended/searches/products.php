<?php

use Kirby\Products\Product;
use Kirby\Toolkit\Str;

return [
    'label' => 'Products',
    'icon'  => 'cart',
    'query' => function (string $query, int $limit) {
        $results = [];

        foreach (Product::list() as $product) {
            if (Str::contains($product['title'], $query, true) === true) {
                $results[] = [
                    'text'  => $product['title'],
                    'link'  => '/products/' . $product['id'],
                    'image' => [
                        'icon' => 'cart',
                        'back' => 'purple-400'
                    ]
                ];
            }
        }

        // only return as many results as the search asks for
        return array_slice($results, 0, $limit);
    }
];
