<?php

load([
    'Kirby\Products\Product' => __DIR__ . '/classes/Product.php'
]);

Kirby::plugin(
    name: 'getkirby/products',
    extends: [
        'areas' => [
            'products' => [
                'label'   => 'Products',
                'icon'    => 'cart',
                'menu'    => true,
                // create, update and delete dialogs
                'dialogs' => [
                    require __DIR__ . '/dialogs/create.php',
                    require __DIR__ . '/dialogs/update.php',
                    require __DIR__ . '/dialogs/delete.php'
                ],
                // dropdown with edit and delete buttons
                'dropdowns' => [
                    require __DIR__ . '/dropdowns/product.php'
                ],
                // search for products, used as default search in all views of the area
                'search'   => 'products',
                'searches' => [
                    'products' => require __DIR__ . '/searches/products.php'
                ],
                // view routes
                'views' => [
                    require __DIR__ . '/views/products.php',
                    require __DIR__ . '/views/product.php'
                ]
            ]
        ]
    ]
);
