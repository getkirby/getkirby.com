<?php

use Kirby\Products\Product;
use Kirby\Toolkit\HtmlString;

return [
    'pattern' => 'products/(:any)/delete',
    'load'    => function (string $id) {
        $product = Product::find($id);

        return [
            'component' => 'k-remove-dialog',
            'props'     => [
                // the title is escaped, the <strong> tag is kept
                'text' => HtmlString::translate('Do you really want to delete <strong>{title}</strong>?', [
                    'title' => $product['title']
                ])
            ]
        ];
    },
    'submit' => function (string $id) {
        Product::delete($id);

        // always redirect to the products list,
        // especially when the product is deleted
        // from its own view
        return [
            'redirect' => 'products'
        ];
    }
];
