<?php

use Kirby\Products\Product;

return [
    'pattern' => 'products/(:any)',
    'action'  => function (string $id) {
        $product = Product::find($id);

        return [
            'component'  => 'k-product-view',
            'title'      => $product['title'],
            'breadcrumb' => [
                [
                    'label' => $product['title'],
                    'link'  => 'products/' . $id
                ]
            ],
            'props' => [
                'product' => $product
            ]
        ];
    }
];
