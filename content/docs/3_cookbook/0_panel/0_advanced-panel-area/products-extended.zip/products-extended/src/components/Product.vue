<template>
  <k-panel-inside>
    <k-header>
      {{ product.title }}
      <template #buttons>
        <k-button-group>
          <k-button
            icon="edit"
            size="sm"
            text="Edit"
            variant="filled"
            @click="$panel.dialog.open('products/' + product.id + '/update')"
          />
          <k-button
            icon="trash"
            size="sm"
            text="Delete"
            variant="filled"
            @click="$panel.dialog.open('products/' + product.id + '/delete')"
          />
        </k-button-group>
      </template>
    </k-header>
    <table class="k-products">
      <thead>
        <tr>
          <th class="k-product-type">Type</th>
          <th>Description</th>
          <th class="k-product-price">Price</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="k-product-type">{{ product.type }}</td>
          <td>{{ product.description }}</td>
          <td class="k-product-price">{{ price(product.price) }}</td>
        </tr>
      </tbody>
    </table>
  </k-panel-inside>
</template>

<script>
import price from "../helpers/price.js";

export default {
  props: {
    product: Object
  },
  methods: {
    price
  }
};
</script>
