<?php

function products(): array
{
    return Data::read(__DIR__ . '/products.json');
}

Kirby::plugin(
    name: 'getkirby/products',
    extends: [
        'areas' => [
            'products' => [
                'label'   => 'Products',
                'icon'    => 'cart',
                'menu'    => true,
                // update and delete dialogs
                'dialogs' => [
                    require __DIR__ . '/dialogs/update.php',
                    require __DIR__ . '/dialogs/delete.php'
                ],
                // dropdown with edit and delete buttons
                'dropdowns' => [
                    require __DIR__ . '/dropdowns/product.php'
                ],
                // search for products
                'searches' => [
                    'products' => require __DIR__ . '/searches/products.php'
                ],
                // view route
                'views' => [
                    require __DIR__ . '/views/products.php'
                ]
            ]
        ]
    ]
);
