window.panel.plugin('your-project/faq-block', {
  blocks: {
    faq: {
      template: `
        <div @dblclick="open" class="faq">
          <h2>{{ content.headline }}</h2>
          <div v-safe-html="$h($helper.string.sanitizeHTML(content.text, { nodes: true }))"></div>
          <dl v-for="item in content.blocks" :key="item.id">
            <dt>{{ item.content.question }}</dt>
            <dd v-safe-html="$h($helper.string.sanitizeHTML(item.content.answer, { nodes: true }))"></dd>
          </dl>
        </div>
      `
    },
    faqItem: {
      template: `
        <div>
          <strong>
            <k-input
              v-bind="field('question')"
              :value="content.question"
              @input="update({ question: $event })">
            </k-input>
          </strong>
          <p>
            <k-writer-input
              v-bind="field('answer')"
              :value="content.answer"
              @input="update({ answer: $event })">
            </k-writer-input>
          </p>
        </div>
      `
    }
  }
});
