# Jobkit

Example site for the Kirby cookbook recipe
[Forms with attachments](https://getkirby.com/docs/cookbook/forms/email-with-attachments).

It shows how to send form input together with uploaded files by email,
using a job application form as example. Applicants can attach up to
three PDF files, which are sent as attachments of the email.

## Requirements

PHP 8.3 or newer. Kirby itself is not included, see below for how to add it.

## Get going

The kit sends emails. Set up an email transport in `site/config/config.php` first,
e.g. a local mail catcher like [Mailpit](https://mailpit.axllent.org).

Install Kirby with Composer and start the PHP development server:

    composer install
    composer start

Then open http://localhost:8000, pick a job and apply for it.

Without Composer, download Kirby 6 from [GitHub](https://github.com/getkirby/kirby/tags),
unzip it into the kit and rename the folder to `kirby`. Then run the kit on your local
server or with `php -S localhost:8000 kirby/router.php`.

The kit is meant as a learning example and is not ready to be used "as is" in production.

---

© 2009 Bastian Allgeier
[getkirby.com](https://getkirby.com) · [License agreement](https://getkirby.com/license)
