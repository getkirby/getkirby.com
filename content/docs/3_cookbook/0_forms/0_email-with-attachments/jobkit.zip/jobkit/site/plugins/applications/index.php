<?php

use Kirby\Cms\App as Kirby;
use Kirby\Toolkit\Str;

Kirby::plugin(
    name: 'jobkit/application',
    extends: [
        'hooks' => [
            'kirbytags:after' => function (string|null $text, array $data, array $options) {
                // only touch texts that contain our placeholders
                if ($text === null || Str::contains($text, '{{') === false) {
                    return $text;
                }

                $session = kirby()->session();

                if ($reference = $session->get('reference')) {
                    if ($job = page('jobs')->children()->findBy('reference', $reference)) {
                        $title = $job->title() . ' (reference ' . $reference . ')';
                    }
                }

                return Str::template($text, [
                    'job'  => esc($title ?? ''),
                    'name' => esc($session->get('name') ?? '')
                ]);
            }
        ],
    ]
);
