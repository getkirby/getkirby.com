<p>Hello,</p>

<p><?= nl2br(esc($message)) ?></p>

<p>
  Yours sincerely,<br>
  <?= esc($name) ?>
</p>
