<?php snippet('header') ?>

<main>
  <header class="intro">
    <h1><?= $page->title() ?></h1>
  </header>

  <div class="jobs">
    <?php foreach ($page->children()->listed()->sortBy('date', 'desc') as $job): ?>
    <article class="job">
      <header class="job-header">
        <a href="<?= $job->url() ?>">
          <h2><?= $job->title() ?></h2>
          <time><?= $job->date()->toDate('d F Y') ?></time>
          <p>Reference: <em><?= $job->reference()->html() ?></em></p>
        </a>
      </header>
    </article>
    <?php endforeach ?>
  </div>
</main>

<?php snippet('footer') ?>
