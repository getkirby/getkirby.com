<?php snippet('header') ?>

<main>
<main>
  <header class="intro">
    <h1><?= $page->title() ?></h1>
  </header>

  <div class="jobs">
    <?php foreach ($page->children()->listed()->sortBy('date', 'desc') as $job): ?>
    <article class="job">
      <header class="job-header">
        <a href="<?= $job->url() ?>">
          <h2><?= $job->title() ?></h2>
          Published: <time><?= $job->published()->toDate('F d, Y') ?></time>
          <p>Our reference: <em><?= $job->reference()->html() ?></em></p>
        </a>
      </header>
    </article>
    <?php endforeach ?>
  </div>

</main>
</main>

<?php snippet('footer') ?>
