<?php snippet('header') ?>

<main>
  <article class="job">
    <header class="job-header intro">
      <h1><?= $page->title() ?></h1>
      <p>Reference: <?= $page->reference()->html() ?></p>
    </header>

    <div class="text">
      <p>Published on <time><?= $page->date()->toDate('d F Y') ?></time></p>

      <?= $page->text()->kt() ?>

      <p><a href="<?= page('applications')->url(['query' => ['reference' => $page->reference()->value()]]) ?>">Apply for this job</a></p>
    </div>
  </article>
</main>

<?php snippet('footer') ?>
