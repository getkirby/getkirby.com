<form class="application-form" action="<?= $page->url() ?>" method="POST" enctype="multipart/form-data">

  <div class="form-element">
    <label for="name">Name <abbr title="required">*</abbr></label>
    <input type="text" id="name" name="name" value="<?= esc($data['name'] ?? '', 'attr') ?>" required>
  </div>

  <div class="form-element">
    <label for="email">Email <abbr title="required">*</abbr></label>
    <input type="email" id="email" name="email" value="<?= esc($data['email'] ?? '', 'attr') ?>" required>
  </div>

  <div class="form-element">
    <label for="reference">Job reference number <abbr title="required">*</abbr></label>
    <input type="text" id="reference" name="reference" value="<?= esc($data['reference'] ?? get('reference', ''), 'attr') ?>" required>
  </div>

  <div class="form-element">
    <label for="message">Message <abbr title="required">*</abbr></label>
    <textarea id="message" name="message" required><?= esc($data['message'] ?? '') ?></textarea>
  </div>

  <div class="form-element">
    <label for="file">
      Your documents <abbr title="required">*</abbr>
      <span class="help">Up to 3 PDF files, max. 2 MB each</span>
    </label>
    <input type="file" id="file" name="file[]" accept="application/pdf" multiple required>
  </div>

  <div class="honey">
    <label for="website">If you are a human, leave this field empty</label>
    <input type="url" id="website" name="website" tabindex="-1" autocomplete="off">
  </div>

  <input type="hidden" name="csrf" value="<?= csrf() ?>">
  <input class="application-button" type="submit" name="submit" value="Apply">

</form>
