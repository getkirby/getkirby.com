<?php

return [
    'debug' => true,

    // the kit sends emails, so it needs an email transport,
    // e.g. a local mail catcher like Mailpit:
    // 'email' => [
    //     'transport' => [
    //         'type' => 'smtp',
    //         'host' => 'localhost',
    //         'port' => 1025
    //     ]
    // ],
];
