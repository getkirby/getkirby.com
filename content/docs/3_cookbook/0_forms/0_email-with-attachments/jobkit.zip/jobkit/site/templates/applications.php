<?php snippet('header') ?>

<main>
  <article class="applications">
    <header class="application-header intro">
      <h1><?= $page->title() ?></h1>
    </header>

    <div class="text">
      <?= $page->text()->kt() ?>
    </div>

    <?php
    // if the form input is not valid, show a list of alerts
    if ($alerts): ?>
    <div class="alert">
      <ul>
        <?php foreach ($alerts as $message): ?>
        <li><?= esc($message) ?></li>
        <?php endforeach ?>
      </ul>
    </div>
    <?php endif ?>

    <?php snippet('application-form', ['data' => $data]) ?>
  </article>
</main>

<?php snippet('footer') ?>
