<?php

use Kirby\Filesystem\Dir;
use Kirby\Filesystem\F;
use Kirby\Filesystem\Mime;
use Kirby\Toolkit\Str;

return function ($kirby, $page) {

    // if the form has been submitted…
    if ($kirby->request()->is('POST') && get('submit')) {

        // check the honeypot and exit if it has been filled in
        if (empty(get('website')) === false) {
            go($page->url());
        }

        $alerts = [];
        $data   = [
            'name'      => get('name'),
            'email'     => get('email'),
            'reference' => get('reference'),
            'message'   => get('message')
        ];

        // check the CSRF token to make sure the request came from our form
        if (csrf(get('csrf')) !== true) {
            return [
                'alerts' => ['Your session has expired. Please submit the form again.'],
                'data'   => $data
            ];
        }

        $rules = [
            'name'      => ['required', 'min' => 3],
            'email'     => ['required', 'email'],
            'reference' => ['required', 'in' => [page('jobs')->children()->listed()->pluck('reference', ',')]],
            'message'   => ['required', 'min' => 10, 'max' => 3000],
        ];

        $messages = [
            'name'      => 'Please enter a valid name.',
            'email'     => 'Please enter a valid email address.',
            'reference' => 'Please enter a valid reference.',
            'message'   => 'Please enter a text between 10 and 3000 characters.'
        ];

        // some of the data is invalid
        if ($invalid = invalid($data, $rules, $messages)) {
            $alerts = $invalid;
        }

        // get the uploads
        $uploads = $kirby->request()->files()->get('file') ?? [];

        // we want no more than 3 files
        if (count($uploads) > 3) {
            $alerts[] = 'You may only upload up to 3 files.';
        }

        // valid uploads are moved to a temporary folder of their
        // own, so they can be attached with their original name
        $folder      = sys_get_temp_dir() . '/application-' . Str::random(16);
        $attachments = [];

        // loop through uploads and check if they are valid
        foreach ($uploads as $upload) {
            // make sure the user uploads at least one file
            if ($upload['error'] === UPLOAD_ERR_NO_FILE) {
                $alerts[] = 'You have to attach at least one file.';
            // make sure there are no other errors
            } elseif ($upload['error'] !== UPLOAD_ERR_OK) {
                $alerts[] = 'The file could not be uploaded.';
            // make sure the file is not larger than 2 MB…
            } elseif ($upload['size'] > 2000000) {
                $alerts[] = $upload['name'] . ' is larger than 2 MB.';
            // …and the file is a PDF: we check the file itself,
            // because the type sent by the browser can be faked
            } elseif (Mime::type($upload['tmp_name']) !== 'application/pdf') {
                $alerts[] = $upload['name'] . ' is not a PDF.';
            // all valid, move the file with a sanitized name
            } else {
                Dir::make($folder);

                $file = $folder . '/' . F::safeName($upload['name']);

                if (move_uploaded_file($upload['tmp_name'], $file) === true) {
                    $attachments[] = $file;
                }
            }
        }

        // the data is fine, let's send the email with attachments
        if (empty($alerts) === true) {
            try {
                $kirby->email([
                    'template'    => 'email',
                    'from'        => 'yourcontactform@yourcompany.com',
                    'replyTo'     => $data['email'],
                    'to'          => 'you@yourcompany.com',
                    'subject'     => $data['name'] . ' applied for job ' . $data['reference'],
                    'data'        => $data,
                    'attachments' => $attachments
                ]);
            } catch (Exception $error) {
                // we only display a general error message, for debugging use `$error->getMessage()`
                $alerts[] = 'The email could not be sent.';
            }
        }

        // the files are no longer needed, whether the email was sent or not
        Dir::remove($folder);

        // no exception occurred, let's send a success message
        if (empty($alerts) === true) {
            // store reference and name in the session for use on the success page
            $kirby->session()->set([
                'reference' => $data['reference'],
                'name'      => $data['name']
            ]);

            // redirect to the success page
            go('success');
        }
    }

    // return data to template
    return [
        'alerts' => $alerts ?? null,
        'data'   => $data ?? false,
    ];
};
