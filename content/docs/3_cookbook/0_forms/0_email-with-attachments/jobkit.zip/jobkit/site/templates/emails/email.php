Hello,

<?= $message ?>


Yours sincerely,
<?= $name ?>
