<?php snippet('header') ?>

<main>
  <header class="intro">
    <h1><?= $site->title() ?></h1>
  </header>

  <div class="text">
    <p>This kit demonstrates how to send a form with file attachments by email.</p>
    <p>To see it in action, head over to the <a href="<?= page('jobs')->url() ?>">Jobs page</a> and select a job. Each job page links to the application form, where you can apply with up to three PDF files.</p>
    <p>The kit sends the application by email. Set up an email transport in <code>site/config/config.php</code> before you try it.</p>
  </div>
</main>

<?php snippet('footer') ?>
