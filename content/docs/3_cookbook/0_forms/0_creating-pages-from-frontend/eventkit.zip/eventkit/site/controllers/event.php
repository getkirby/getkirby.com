<?php

use Kirby\Toolkit\Str;

return function ($kirby, $page) {

    // if the form has been submitted…
    if ($kirby->request()->is('POST') && get('register')) {

        // check the honeypot and exit if it has been filled in
        if (empty(get('website')) === false) {
            go($page->url());
        }

        $data = [
            'name'    => get('name'),
            'company' => get('company'),
            'email'   => get('email'),
            'message' => get('message')
        ];

        $rules = [
            'name'  => ['required'],
            'email' => ['required', 'email'],
        ];

        $messages = [
            'name'  => 'Please enter your (link: #name text: name)',
            'email' => 'Please enter a valid (link: #email text: email address)',
        ];

        // check the CSRF token to make sure the request came from our form
        if (csrf(get('csrf')) !== true) {
            $alert = ['Your session has expired. Please submit the form again.'];

        // some of the data is invalid
        } elseif ($invalid = invalid($data, $rules, $messages)) {
            $alert = $invalid;

        } else {

            // everything is ok, let's try to create a new registration
            try {
                // authenticate as almighty, but only for this one action
                $registration = $kirby->impersonate('kirby', function () use ($page, $data) {
                    // we store registrations as subpages of the current page
                    return $page->createChild([
                        'slug'     => md5(Str::slug($data['name']) . microtime()),
                        'template' => 'registration',
                        'content'  => $data
                    ]);
                });

                if ($registration) {
                    // store referer and name in session
                    $kirby->session()->set([
                        'referer' => $page->uri(),
                        'regName' => esc($data['name'])
                    ]);
                    go('success');
                }

            } catch (Exception $e) {
                $alert = ['Your registration failed: ' . $e->getMessage()];
            }
        }
    }

    // return data to template
    return [
        'alert' => $alert ?? null,
        'data'  => $data ?? false,
    ];
};
