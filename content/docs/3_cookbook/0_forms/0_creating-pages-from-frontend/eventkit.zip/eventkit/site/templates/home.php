<?php snippet('header') ?>

<main>
  <header class="intro">
    <h1><?= $site->title() ?></h1>
  </header>

  <div class="text">
    <p>This kit demonstrates how to create pages from the frontend.</p>
    <p>To see it in action, head over to the <a href="<?= page('events')->url() ?>">Events page</a> and select an event. On each event page, you can register for the event via the form.</p>
    <p>All registrations are stored as drafts of the event page. Log in to the <a href="<?= url('panel') ?>">Panel</a> to review them.</p>
  </div>
</main>

<?php snippet('footer') ?>
