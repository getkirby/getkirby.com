<form class="registration-form" action="<?= $page->url() ?>" method="POST">

  <div class="form-element">
    <label for="name">Name <abbr title="required">*</abbr></label>
    <input type="text" id="name" name="name" value="<?= esc($data['name'] ?? '', 'attr') ?>" required>
  </div>

  <div class="form-element">
    <label for="company">Company</label>
    <input type="text" id="company" name="company" value="<?= esc($data['company'] ?? '', 'attr') ?>">
  </div>

  <div class="form-element">
    <label for="email">Email <abbr title="required">*</abbr></label>
    <input type="email" id="email" name="email" value="<?= esc($data['email'] ?? '', 'attr') ?>" required>
  </div>

  <div class="form-element">
    <label for="message">Message</label>
    <textarea id="message" name="message"><?= esc($data['message'] ?? '') ?></textarea>
  </div>

  <div class="honey">
    <label for="website">If you are a human, leave this field empty</label>
    <input type="url" id="website" name="website" tabindex="-1" autocomplete="off">
  </div>

  <input type="hidden" name="csrf" value="<?= csrf() ?>">
  <input class="registration-button" type="submit" name="register" value="Register">

</form>
