<?php

use Kirby\Cms\App as Kirby;
use Kirby\Toolkit\Str;

Kirby::plugin(
    name: 'eventkit/event',
    extends: [
        'hooks' => [
            'kirbytags:after' => function (string|null $text, array $data, array $options) {
                // only touch texts that contain our placeholders
                if ($text === null || Str::contains($text, '{{') === false) {
                    return $text;
                }

                $session = kirby()->session();

                if ($location = $session->get('referer')) {
                    if ($page = page(urldecode($location))) {
                        $title = $page->title()->escape();
                    }
                }

                return Str::template($text, [
                    'event' => $title ?? '',
                    'name'  => $session->get('regName') ?? ''
                ]);
            }
        ],
    ]
);
