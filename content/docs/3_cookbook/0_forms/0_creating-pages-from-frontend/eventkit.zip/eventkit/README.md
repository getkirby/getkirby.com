# Eventkit

Example site for the Kirby cookbook recipe
[Create pages from frontend](https://getkirby.com/docs/cookbook/forms/creating-pages-from-frontend).

It shows how to create pages from user input submitted through a form on the frontend,
using an event registration form as example. Each registration is stored as a draft subpage
of the event and can be reviewed in the Panel.

## Requirements

PHP 8.3 or newer. Kirby itself is not included, see below for how to add it.

## Get going

Install Kirby with Composer and start the PHP development server:

    composer install
    composer start

Then open http://localhost:8000, pick an event and register for it.
Visit http://localhost:8000/panel to create an account and see the registrations.

Without Composer, download Kirby 6 from [GitHub](https://github.com/getkirby/kirby/tags),
unzip it into the kit and rename the folder to `kirby`. Then run the kit on your local
server or with `php -S localhost:8000 kirby/router.php`.

The kit is meant as a learning example and is not ready to be used "as is" in production.

---

© 2009 Bastian Allgeier
[getkirby.com](https://getkirby.com) · [License agreement](https://getkirby.com/license)
