<?php

use Kirby\Cms\App;
use Kirby\Cms\Helpers;
use Kirby\Cms\Html;

if (Helpers::hasOverride('twitter') === false) {
	function twitter(
		string $username,
		string|null $text = null,
		string|null $title = null,
		string|null $class = null
	): string {
		return App::instance()->kirbytag([
			'twitter' => $username,
			'text'    => $text,
			'title'   => $title,
			'class'   => $class
		]);
	}
}

App::plugin('getkirby/legacy-twitter', [
	'tags' => [
        'twitter' => [
		'attr' => [
			'class',
			'rel',
			'target',
			'text',
			'title'
		],
		'html' => function ($tag) {
			// get and sanitize the username
			$username = str_replace('@', '', $tag->value);

			// build the profile url
			$url = 'https://twitter.com/' . $username;

			// sanitize the link text
			$text = $tag->text ?? '@' . $username;

			// build the final link
			return Html::a($url, $text, [
				'class'  => $tag->class,
				'rel'    => $tag->rel,
				'target' => $tag->target,
				'title'  => $tag->title,
			]);
		}
	],
    ]
]);