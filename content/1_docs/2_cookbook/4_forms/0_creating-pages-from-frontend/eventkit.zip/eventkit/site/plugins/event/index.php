<?php

Kirby::plugin('eventkit/event', [
    'hooks' => [
        'kirbytags:after' => function ($text, $data, $options) {
            $session = kirby()->session();
            $title = '';
            $name  = '';

            if ($location = $session->get('referer')) {
                if ($page = page(urldecode($location))) {
                    $title = $page->title();
                }
            }
            if ($name = $session->get('regName')) {
                $name = $name;
            }

            return Str::template($text, ['name' => $name, 'event' => $title]);
        }
    ],
]);