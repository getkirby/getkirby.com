<?php snippet('header') ?>
<main>
  <article class="event">
    <header class="event-header intro">
      <h1><?= $page->title() ?></h1>
      <time class="event-date"><?= $page->date()->toDate('d F Y') ?></time>
    </header>
    <div class="text">
      <?= $page->text()->kt() ?>
    </div>
    <div class="registration">
      <header class="registration-header">
        <h2>Register for this event</h2>
      </header>
     
      <?php
      // if the form input does not validate, show a list of alerts
      if($alert): ?>
      <div class="alert">
        <ul>
          <?php foreach($alert as $message): ?>
          <li><?= kirbytext($message) ?></li>
          <?php endforeach ?>
        </ul>
      </div>
      <?php endif ?>
      <?php snippet('registration-form', compact('data')); ?> 
    </div>
  </article>
</main>

<?php snippet('footer') ?>