<?php

return function($kirby, $page) {

  $alert = null;

   if($kirby->request()->is('POST') && get('register')) {
        // store the current session in a variable
        $session = $kirby->session();
        // check the honeypot
        if(empty(get('website')) === false) {
            go($page->url());
            exit;
        }

    $data = array(
        'name'    => get('name'),
        'company' => get('company'),
        'email'   => get('email'),
        'message' => get('message')
    );

    $rules = array(
        'name'    => ['required'],
        'email'   => ['required', 'email'],
    );

    $messages = array(
        'name'  => 'Please enter your (link: #name text: name)',
        'email' => 'Please enter a valid (link: #email text: email address)',
    );

    // some of the data is invalid
    if($invalid = invalid($data, $rules, $messages)) {
        $alert = $invalid;
    } else {
        // authenticate as almighty
        $kirby->impersonate('kirby');
        // everything is ok, let's try to create a new registration
        try {
            // we store registrations as subpages of the current page
            if ($registration = $page->createChild([
                'slug'     => md5(str::slug($data['name'] . microtime())),
                'template' => 'registration',
                'content' => $data
                ])) {
                // store referer and name in session   
                $session->set([
                    'referer' => $page->uri(),
                    'regName'  => esc($data['name'])
                    ]);
                $data = [];
                go('success');
            }

        } catch(Exception $e) {
            echo 'Your registration failed: ' . $e->getMessage();
        }
    }
  }
  // return data to template
    return [
        'alert'   => $alert,
        'data'    => $data ?? false,
    ];
};