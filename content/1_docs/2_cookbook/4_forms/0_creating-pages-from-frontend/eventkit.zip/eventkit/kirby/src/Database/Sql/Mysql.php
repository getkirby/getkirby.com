<?php

namespace Kirby\Database\Sql;

use Kirby\Database\Sql;

/**
 * Mysql query builder
 */
class Mysql extends Sql
{
}
