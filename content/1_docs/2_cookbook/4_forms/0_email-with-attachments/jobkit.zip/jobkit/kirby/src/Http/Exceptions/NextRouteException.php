<?php

namespace Kirby\Http\Exceptions;

class NextRouteException extends \Exception
{
}
