<?php snippet('header') ?>
<main>
  <article class="applications">
    <header class="application-header intro">
      <h1><?= $page->title() ?></h1>
    </header>
    <div class="text">
      <?= $page->text()->kt() ?>
    </div>
    <div class="job">

      <?php
      // if the form input does not validate, show a list of alerts
      if($alerts): ?>
      <div class="alert">
        <ul>
          <?php foreach($alerts as $message): ?>
          <li><?= kirbytext($message) ?></li>
          <?php endforeach ?>
        </ul>
      </div>
      <?php endif ?>
      <?php snippet('application-form', compact('data')); ?> 
    </div>
  </article>
</main>

<?php snippet('footer') ?>