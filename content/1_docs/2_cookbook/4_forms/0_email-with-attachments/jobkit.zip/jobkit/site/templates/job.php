<?php snippet('header') ?>

<main>
  <article class="job">
    <header class="job-header intro">
      <h1><?= $page->title() ?></h1>
      <p>Reference: <?= $page->reference()->html() ?></p>
    </header>
    <div class="text">
      <p>Published on: <time class="job-publication-date"><?= $page->published()->toDate('Y-m-d') ?></time></p>

      <?= $page->text()->kt() ?>
      <a href="<?= page('applications')->url() . '?reference=' . $page->reference()->html() ?>">Apply for this job</a>
    </div>
  </article>
</main>

<?php snippet('footer') ?>