<?php

return [
    'email' => 'sonja@imap.cc',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];