<?php snippet('header') ?>

<main>
  <header class="intro">
    <h1><?= $site->title() ?></h1>
  </header>

  <div class="text">
    <p>This kit shows how to send forms with attachments</p>
    <p>Each <a href="<?= page('jobs')->url() ?>">Job page</a> contains a link to an applications page with a form.</p>
  </div>
  
<main>


<?php snippet('footer') ?>
