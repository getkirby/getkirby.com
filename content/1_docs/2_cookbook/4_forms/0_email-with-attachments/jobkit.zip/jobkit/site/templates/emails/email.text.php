<?php
echo($message);